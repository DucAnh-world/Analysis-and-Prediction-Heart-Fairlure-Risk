import streamlit as st
import numpy as np
import pandas as pd
import xgboost as xgb
import pickle
import shap
from matplotlib import pyplot as plt
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import tempfile
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from PyPDF2 import PdfMerger

model = pickle.load(open("model_xgb.pkl", "rb"))

st.set_page_config(page_title="Heart Disease Prediction")

st.title("Dự đoán nguy cơ mắc bệnh tim")
st.write("Ứng dụng demo sử dụng **XGBoost** và **Streamlit**")


age = st.number_input("Tuổi", min_value=20, max_value=100, value=50)
sex = st.selectbox("Giới tính (1=Nam, 0=Nữ)", [0, 1])
cp = st.selectbox("Loại đau ngực (0-3)", [0, 1, 2, 3])
trestbps = st.number_input("Huyết áp khi nghỉ (mm Hg)", min_value=80, max_value=200, value=120)
chol = st.number_input("Cholesterol (mg/dl)", min_value=100, max_value=600, value=200)
fbs = st.selectbox("Đường huyết > 120 mg/dl? (1=Có, 0=Không)", [0, 1])
restecg = st.selectbox("Kết quả điện tâm đồ (0-2)", [0, 1, 2])
thalach = st.number_input("Nhịp tim tối đa đạt được", min_value=60, max_value=220, value=150)
exang = st.selectbox("Đau ngực khi gắng sức? (1=Có, 0=Không)", [0, 1])
oldpeak = st.number_input("ST depression", min_value=0.0, max_value=10.0, value=1.0, step=0.1)
slope = st.selectbox("Độ dốc đoạn ST (0-2)", [0, 1, 2])
ca = st.selectbox("Số lượng mạch chính (0-3)", [0, 1, 2, 3])
thal = st.selectbox("Thalassemia (1=normal; 2=fixed defect; 3=reversible defect)", [1, 2, 3])


input_data = pd.DataFrame([[age, sex, cp, trestbps, chol, fbs, restecg,
                            thalach, exang, oldpeak, slope, ca, thal]],
                          columns=["age", "sex", "cp", "trestbps", "chol", "fbs",
                                   "restecg", "thalach", "exang", "oldpeak",
                                   "slope", "ca", "thal"])

prediction = model.predict(input_data)[0]
proba = model.predict_proba(input_data)[0][1] * 100
if st.button("Dự đoán"):
    if prediction == 1:
        st.error(f"⚠️ Nguy cơ mắc bệnh tim cao (xác suất: {proba:.2f}%)")
    else:
        st.success(f"✅ Nguy cơ mắc bệnh tim thấp (xác suất: {proba:.2f}%)")

explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(input_data)

st.subheader("Giải thích kết quả dự đoán")
st.write("Biểu đồ dưới đây cho thấy mức độ ảnh hưởng của từng đặc trưng:")

fig, ax = plt.subplots()
shap.summary_plot(shap_values, input_data, plot_type="bar", show=False)
st.pyplot(fig)

pdfmetrics.registerFont(TTFont('Arial', 'C:/Windows/Fonts/arial.ttf'))


def export_to_pdf(input_data, predict, probability):
    # Tạo file tạm
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    c = canvas.Canvas(temp_file.name, pagesize=letter)
    c.setFont("Arial", 12)
    c.drawString(50, 750, "Kết quả dự đoán nguy cơ bệnh tim")
    c.drawString(50, 710, "Thông tin đầu vào:")
    y = 690
    for col, val in input_data.iloc[0].items():
        c.drawString(70, y, f"{col}: {val}")
        y -= 20

    c.drawString(50, y - 10, "Kết quả dự đoán:")
    c.drawString(70, y - 30, f"Nguy cơ: {predict}")
    c.drawString(70, y - 50, f"Xác suất: {probability:.2f}")

    c.save()
    if shap_values is not None:
        figure = plt.figure()
        shap.summary_plot(shap_values, input_data, plot_type="bar", show=False)
        shap_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        plt.savefig(shap_file.name, bbox_inches="tight")
        plt.close(figure)

        # Ghép 2 file PDF lại
        merger = PdfMerger()
        merger.append(temp_file.name)   # trang kết quả
        merger.append(shap_file.name)   # trang biểu đồ
        merger.write(temp_file.name)    # ghi đè lại file gốc
        merger.close()
    return temp_file.name


if st.button("Xuất kết quả ra PDF"):
    pdf_path = export_to_pdf(input_data, prediction, proba)
    with open(pdf_path, "rb") as f:
        st.download_button("Tải PDF", f, file_name="ket_qua_du_doan.pdf")
        st.write("Xuất file PDF thành công!")
