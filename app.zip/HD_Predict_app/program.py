import numpy as np
import pandas as pd
from scipy.stats import f_oneway
from scipy.stats import chi2_contingency
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier, plot_importance
from sklearn.model_selection import GridSearchCV
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import classification_report
import pickle
from sklearn.model_selection import StratifiedKFold

df = pd.read_csv('Heart_disease_cleveland_new.csv')
df.head()
numerical_cols = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak']
categorical_cols = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca']



print("ANOVA F-test for numerical variables vs target:\n")
for col in numerical_cols:
    groups = [df[col][df['target'] == group] for group in df['target'].unique()]
    f_statistic, p_value = f_oneway(*groups)
    print(f"{col}: F-statistic = {f_statistic:.4f}, p-value = {p_value:.4f} {'(Significant)' if p_value < 0.05 else '(Not significant)'}")


print("Chi-square test for categorical variables:\n")
for col in categorical_cols:
    table = pd.crosstab(df[col], df['target'])
    stat, p, _, _ = chi2_contingency(table)
    print(f"{col}: p-value = {p:.4f} {'(Significant)' if p < 0.05 else '(Not significant)'}")

imputer = SimpleImputer(strategy='most_frequent')
df['ca'] = imputer.fit_transform(df[['ca']]).ravel()
df['thal'] = imputer.fit_transform(df[['thal']]).ravel()

X = df.drop(['target'], axis=1)
y = df['target']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
num_cols = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak']

scaler = StandardScaler()

X_train_scaled = X_train.copy()
X_test_scaled = X_test.copy()

X_train_scaled[num_cols] = scaler.fit_transform(X_train[num_cols])
X_test_scaled[num_cols] = scaler.transform(X_test[num_cols])

param_grid_xgb = {
    'n_estimators': [100],
    'learning_rate': [0.1],
    'max_depth': [3],
    'subsample': [1.0]
}

xgb = XGBClassifier(eval_metric='logloss', random_state=42)

xgb.fit(X_train_scaled, y_train)

y_pred = xgb.predict(X_test_scaled)

model_path = "xgb_model.pkl"
with open("model_xgb.pkl", "wb") as f:
    pickle.dump(xgb, f)

print("Model saved successfully!")


